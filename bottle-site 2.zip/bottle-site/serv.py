import RPi.GPIO as GPIO
import time

def otkr():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(23,GPIO.OUT)
    p=GPIO.PWM(23,50)
    p.start(2.5)
    p.ChangeDutyCycle(2.5)
    time.sleep(0.5)
    p.stop()
    GPIO.cleanup()

def zakr():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(23,GPIO.OUT)
    p=GPIO.PWM(23,50)
    p.start(12)
    p.ChangeDutyCycle(12)
    time.sleep(0.5)
    p.stop()
    GPIO.cleanup()

def remont1():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(23,GPIO.OUT)
    p=GPIO.PWM(23,50)
    p.start(12)
    p.ChangeDutyCycle(2.5)
    time.sleep(0.1)
    p.ChangeDutyCycle(12)
    time.sleep(0.1)
    p.ChangeDutyCycle(2.5)
    time.sleep(0.1)
    p.ChangeDutyCycle(12)
    time.sleep(0.1)
    p.stop()
    GPIO.cleanup()


def pusk():
    GPIO.setmode(GPIO.BCM) 
    GPIO.setup(18, GPIO.OUT) 
    p = GPIO.PWM(18, 100) 
    p.start(4)
    p.ChangeDutyCycle(10.5) # may need to be adjusted #321
    time.sleep(5)
    p.ChangeDutyCycle(2.5) 
    time.sleep(0.2) 
    p.ChangeDutyCycle(20.5) 
    time.sleep(0.2)
    p.ChangeDutyCycle(2.5) 
    time.sleep(0.3) 
    p.ChangeDutyCycle(20.5) 
    time.sleep(0.3)
    p.stop()
    GPIO.cleanup()
   
def remont2():
    GPIO.setmode(GPIO.BCM) 
    GPIO.setup(18, GPIO.OUT) 
    p = GPIO.PWM(18, 100) 
    p.start(4)
    p.ChangeDutyCycle(2.5) 
    time.sleep(0.2) 
    p.ChangeDutyCycle(20.5) 
    time.sleep(0.2)
    p.ChangeDutyCycle(2.5) 
    time.sleep(0.3) 
    p.ChangeDutyCycle(20.5) 
    time.sleep(0.3)
    p.ChangeDutyCycle(2.5) 
    time.sleep(0.3) 
    p.stop()
    GPIO.cleanup()

