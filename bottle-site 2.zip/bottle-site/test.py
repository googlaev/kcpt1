from create_map import *
from translate import *
import pymorphy2

#create_temp_file("gamer_text.txt", "temp.txt")
#create_map_file("gop_map.txt", "template1.txt")


f = open("text.txt", "r")
text = f.read()
f.close()
text = translate("revchild_map.txt", text)
f = open("result.txt", "w")
f.write( text )
f.close()
print( text )

"""
f = open("children_source.txt", "r")
text = f.read().lower()
f.close()

f = open("child_map.txt", "w")
f.write( text )
f.close()
"""

"""
f = open("child_map.txt", "r")
words = f.read().split("\n")
words = [e.split(": ") for e in words]
f.close()
#print( words )

morph = pymorphy2.MorphAnalyzer()
#w = words[5][0]
#w = morph.parse(w)[0]
#print( w.inflect({'datv'}).word )

m = {}
morphs = ['nomn', 'gent', 'datv', 'accs', 'ablt', 'loct']
for (k, v) in words:
	m[k] = v
	#print( k, v )
	w = morph.parse(k)[0]
	v = v.split()
	v = [morph.parse(e)[0] for e in v]
	try:
		for p in morphs[1:]:
			m[w.inflect({p}).word] = " ".join( [e.inflect({p}).word for e in v] )
		for p in morphs:
			m[w.inflect({p,'plur'}).word] = " ".join( [e.inflect({p,'plur'}).word for e in v] )
	except:
		continue
f = open("child_map.txt", "w")
f.write( str(m) )
f.close()
"""
"""
f = open("child_map.txt", "r")
text = f.read().split("\n")
text = list(map(lambda e: e.split(": "),text))
f.close()
text.sort(key=lambda e: len(e[0].split(" ")),reverse=True)
text = text[:-1]
text = list(map(lambda e: "{}: {}".format(e[0],e[1]), text))
f = open("child_map.txt", "w")
f.write("\n".join(text))
f.close()
"""
"""
f = open("gamer_map.txt", "r")
m = eval(f.read())
f.close()
nm = {}
for e in m:
	if e == ".": continue
	nm[m[e]] = e

f = open("revgamer_map.txt", "w")
f.write( str(nm) )
f.close()
"""
"""
f = open("revchild_map.txt", "r")
m = eval( f.read() )
for e in m:
	print( e )
"""