#библиотеки: регулярные выражения; функции первого порядка
import re
import functools as ft

#функция запуска подмен
#вход: имя файла словаря; текст для подмены
#выход: текст с подменами
def translate(mapfile, source):
	#открываем словарь тематических замен
	f = open( mapfile, "r" )
	m = eval( f.read() )#на выходе получаем словарь m
	f.close()

	words = source

	#разбираем текст на слова с помощью регулярки
	p = re.compile("[a-zA-Zа-яА-ЯёЁ\-]+|[.,:;!?]")
	words = p.findall(words)

	#добавляем к списку состояние (1 переведен - 0 не переведен)
	words = list(map(lambda e: (e, 0), words))

	#цикл для подмены слов
	for j in range(3,-1,-1):
		for i in range(len(words) - j):
			w = words[i:i+j+1]#делаем срез слов
			count = ft.reduce(lambda a, e: a + e[1], w, 0)#считаем кол-во подмен
			if count != 0: continue#если подмены в срезе есть, то идем дальше
			key = " ".join(list(map(lambda e: e[0].lower(), w)))#приобразуем срез в ключ для поиска в словаре
			if key not in m: continue#если не найдено в словаре то идем дальше
			#делаем подмену и меняем состояние		
			words[i] = (m[key], 1)
			for c in range(i+1,i+j+1):
				words[c] = ("", 1)

	words = list(map(lambda e: e[0], words))#удаляем из списка состояние
	words = list(filter(lambda e: e != "", words))#удаляем пустые слова
	text = " ".join(words)#преобразуем в текс

	return text
