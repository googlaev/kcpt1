import re

#функция создания временного шаблона для создания словаря подмен
#вход: имя файла с примерами тематического текста; имя для временного файла шаблона подмен
#выход: создает файл шаблона подмен
def create_temp_file(sourcefile, tempfile):

	#открываем файл с исходным текстом
	f = open( sourcefile, "r" )
	words = f.read()
	f.close()

	#разбираем текст на слова
	p = re.compile("[,.:!?/s]?([a-zA-Zа-яА-ЯёЁ0-9\-]+)[,.:!?/s]?")
	p = p.findall(words)

	#создаем для словарь для записи шаблона подмен
	m = {}
	for j in range(3,-1,-1):
		for i in range(len(p) - j):
			if j == 3:
				m[(p[i], p[i+1], p[i+2], p[i+3])] = "*"
			if j == 2:
				m[(p[i], p[i+1], p[i+2])] = "*"
			if j == 1:
				m[(p[i], p[i+1])] = "*"
			if j == 0:
				m[(p[i],)] = "*"

	#сохраняем данные в файл-шаблон
	f = open( tempfile, "w" )
	f.write("# * - не создавать подмену, . - удалить выражение\n")
	for k in m:
		i = len(k) - 1
		str = "{}" + " {}" * i + ": *\n"
		t = tuple(map(lambda e: e.lower(), k))
		f.write( str.format(*t) )
	f.close()

#функция создания тематического словаря
#вход: имя временного файла шаблона подмен
#выход: создает файл тематического словаря
def create_map_file(mapfile, tempfile):

	#открываем временно созданный файл с шаблоном подмен
	f = open( tempfile, "r" )
	words = f.read()
	f.close()
	p = re.compile("([a-zA-Zа-яА-ЯёЁ\-\s]+):\s([a-zA-Zа-яА-ЯёЁ\-*.\s]+)\n")
	words = p.findall(words)
	#оформляем список кортежей в виде словаря
	m = {}
	for (w1, w2) in words:
		if w2 == "*": continue
		if w2 == ".":
			m[w1] = ""
			continue
		m[w1] = w2

	#сохраняем словарь с синтаксисом питона
	f = open( mapfile, "w" )
	f.write( str(m) )
	f.close()
