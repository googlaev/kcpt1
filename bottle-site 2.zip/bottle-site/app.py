#!/usr/bin/env python
#-*- coding: utf-8 -*-
import datetime
#import serv
import os
from bottle import route, run, static_file, template, view
from bottle import get, post, request ,FormsDict# or route
from translate import *  
now = datetime.datetime.now()
def log_write(a):
    f=open('log.txt','a')
    f.write(a+'\n')
    f.close()
@route('/js/<filename>')
def js_static(filename):
    return static_file(filename, root='./js')

@route('/img/<filename>')
def img_static(filename):
    return static_file(filename, root='./img')

@route('/css/<filename>')
def img_static(filename):
    return static_file(filename, root='./css')

@get("/")
@view("main")
def hello():
    #tex1 = request.forms.get("text")
    #print(tex1)
    return dict(title = "Hello", content = "Hello from Python!")
@post("/")
@view("main")
def hello():
    tex1 = request.forms.text  #get("text").encode('utf-8')
    sel = request.forms.sel
    req = ''
    if sel == '0':
        req=translate('revchild_map.txt',tex1)
    elif sel == '1':
        req=translate('revgamer_map.txt',tex1)
    elif sel == '2':
        req=translate('revgop_map.txt',tex1)
    print(req,sel)
    f = req
    # if tex1 == '1':
	# 	serv.pusk()
	# 	log_write('done: Пуск. ['+ now.strftime("%d-%m-%Y %H:%M") + ']')
	# if tex1 == '2':
	# 	serv.otkr()
	# 	log_write('done: Открыть. ['+ now.strftime("%d-%m-%Y %H:%M") + ']')
	# if tex1 == '3':
	# 	serv.zakr()
	# 	log_write('done: Закрыть. ['+ now.strftime("%d-%m-%Y %H:%M") + ']')
	# if tex1 == '4':
	# 	serv.remont1()
	# 	log_write('error: Ремонт-1. ['+ now.strftime("%d-%m-%Y %H:%M") + ']')
	# if tex1 == '5':
	# 	serv.remont2()
	# 	log_write('error: Ремонт-2. ['+ now.strftime("%d-%m-%Y %H:%M") + ']')	
    return  f  #dict(title = "Hello", content = f)

@route('/log')
@view("main1")
def logg():
    f = open('log.txt').read().split("\n")
    stt ='1234'
    for i in f:
        print (i)
    for i in f:
        if "er" in i:
            stt+= '<div class="alert alert-danger" role="alert">   '+i+'     </div> '
            print(stt)
        elif "do" in i:
            '<div class="alert alert-success" role="alert">'+ i+ '   </div>'

    return dict(title = "Hello", content = f)

if __name__ == "__main__":


    port = int(os.environ.get("PORT", 5000))
    run(host='0.0.0.0', port=port)
